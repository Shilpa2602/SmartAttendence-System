package com.sss;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Types;

public class GetConnection {
	public void insert(Poso p1)
	{
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
		PreparedStatement ps=con.prepareStatement("update Attendence set percentage=? where roll_no=?");
		
		CallableStatement stm=con.prepareCall("{?= call inc(?)}");  
		stm.setString(2,p1.getRoll_no());  
		stm.registerOutParameter(1,Types.INTEGER);  
		stm.execute();  

		CallableStatement stmt=con.prepareCall("{?= call percentage(?)}");  
		stmt.setString(2,p1.getRoll_no());  
		stmt.registerOutParameter(1,Types.INTEGER);  
		stmt.execute();  
		
		
		  
		int pre=stmt.getInt(1);  
		
		ps.setInt(1, pre);
		ps.setString(2, p1.getRoll_no());
		ps.executeUpdate();
	}
	catch(Exception ee)
	{
		System.out.println(ee);
	}
	}

}
