package User_Interface;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Model {
	public DetailsPoso getData(String roll)
	{
		DetailsPoso pp=new DetailsPoso();
		try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
		PreparedStatement ps=con.prepareStatement("Select *from Attendence where roll_no=?");
		ps.setString(1, roll);
		
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			pp.setRoll_no(rs.getString("roll_no"));
			pp.setName(rs.getString("name"));
			pp.setMonth(rs.getString("nov"));
			pp.setPercentage(rs.getInt("percentage"));
			
		}
		}
		catch(Exception ee)
		{
			System.out.println(ee);
		}
		return pp;
	}

}
