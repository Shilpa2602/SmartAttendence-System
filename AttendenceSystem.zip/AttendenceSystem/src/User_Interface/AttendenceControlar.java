package User_Interface;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AttendenceControlar
 */
@WebServlet("/AttendenceControlar")
public class AttendenceControlar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AttendenceControlar() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		String roll_no=request.getParameter("roll_no");
		
		Model m=new Model();
		PrintWriter pr=response.getWriter();
		DetailsPoso ds=m.getData(roll_no);
		/*System.out.println(ds.getName());
		System.out.println(ds.getPercentage());
		System.out.println(ds.getMonth());*/
		HttpSession session = request.getSession();
		session.setAttribute("DetailsPoso", ds);
		/*if(ds.getRoll_no()==roll_no)
		{
			request.getRequestDispatcher("Details.jsp").forward(request,response);
		}
		else {
			pr.println("<script> alert('Your Id Is Created Please Login Your Account....')</script");
			request.getRequestDispatcher("Home.jsp").forward(request, response);
		}*/
		
		if(ds.getPercentage()==0)
		{
			pr.println("<script> alert('Please Enter Correct Roll Number....')</script");
			request.getRequestDispatcher("Home.jsp").include(request, response);
			//pr.println("<html><body>Bhushan</body></html>");
		}
		else
		request.getRequestDispatcher("Details.jsp").forward(request, response);
		
		
		
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
